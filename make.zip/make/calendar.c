//calendar.c

#include "diary.h"
void calendar() {
printf("Show calendar.c \n");
}
